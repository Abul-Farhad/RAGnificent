from params.agent_params import AgentParams
from base_model.base_rag_model import BaseRagModel
class SimpleRag(BaseRagModel):
    def __init__(self, params: AgentParams):
        self.params = params
        super().__init__(params)


# if __name__ == '__main__':
#     def add(x: int, y: int) -> int:
#         """
#         Add a and b.
#         Args:
#             a: first int
#             b: second int
#
#         """
#         print("--- add method called ---")
#         return x + y
#     tools = [add]
#     chatbot = SimpleRag(
#         params=AgentParams(
#             groq_model='deepseek-r1-distill-llama-70b',
#             groq_api_key="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",
#             system_prompt="You are a helpful ai assistant.",
#             summary_prompt="Summary the prompt in a concise manner.",
#             thread_id=1,
#             user_information={
#                 "Name": "Sakib"
#             },
#             tools=tools
#
#         )
#     ).initiate_chatbot()
#     print(chatbot)
#     while True:
#         messages = input("Say anything (enter q to quit): ")
#         if messages == "q":
#             break
#         response = chatbot.run(messages=messages)
#         print(response)
